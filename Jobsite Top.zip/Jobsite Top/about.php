<?php require "includes/header.php" ?>

    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url('images/banner/gen-banner2.png');" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">About Us</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php APPURL; ?>">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>About Us</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="py-5 bg-image overlay-primary fixed overlay" id="next-section" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2 text-white">Job posted stats over 4 years</h2>
            <p class="lead text-white" style="font-size: 16px;">Over four years, the job site grew significantly, connecting more candidates with jobs and expanding its network of companies. It has become a trusted resource for job seekers and employers alike.</p>
          </div>
        </div>
        <div class="row pb-0 block__19738 section-counter">

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="530">0</strong>
            </div>
            <span class="caption">Year 1 (2020)</span>
          </div>

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="1154">0</strong>
            </div>
            <span class="caption">Year 2 (2021)</span>
          </div>

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="1527">0</strong>
            </div>
            <span class="caption">Year 3 (2022)</span>
          </div>

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="1950">0</strong>
            </div>
            <span class="caption">Year 4 (2023)</span>
          </div>


        </div>
      </div>
    </section>


    <section class="site-section pb-0">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 mb-5 mb-lg-0">
            <a data-fancybox data-ratio="2" href="" class="block__96788">
              <!-- <span class="play-icon"><span class="icon-play"></span></span> -->
              <img src="images/banner/freelance.jpg" alt="Image" class="img-fluid img-shadow">
            </a>
          </div>
          <div class="col-lg-5 ml-auto">
            <h2 class="section-title mb-3">JobsiteTop For Freelancers</h2>
            <p class="lead">Whether you're a seasoned professional or just starting your freelance career, we've got you covered. Our platform is designed to connect freelancers with a wide range of exciting and lucrative opportunities.</p>
            <p>At JobsiteTop, we understand the unique needs of freelancers, and we're committed to providing a user-friendly experience tailored specifically to your requirements. Our intuitive interface allows you to easily browse through a diverse selection of freelance jobs across various industries and skill sets.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section pt-0">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-lg-6 mb-5 mb-lg-0 order-md-2">
            <!-- <a data-fancybox data-ratio="2" href="https://vimeo.com/317571768" class="block__96788">
              <span class="play-icon"><span class="icon-play"></span></span> -->
              <img src="images/banner/office.jpg" alt="Image" class="img-fluid img-shadow">
            </a>
          </div>
          <div class="col-lg-5 mr-auto order-md-1  mb-5 mb-lg-0">
            <h2 class="section-title mb-3">JobsiteTop For Office Workers</h2>
            <p class="lead">Whether you're an experienced professional or just starting your career, we're here to help you find your dream job in a traditional office setting.</p>
            <p>At JobsiteTop, we understand the importance of finding the right office-based position that aligns with your skills, interests, and career goals. Our user-friendly portal allows you to explore a wide range of office-based job opportunities across various industries and job functions.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-12 text-center" data-aos="fade">
            <h2 class="section-title mb-3">Meet Our Team</h2>
          </div>
        </div>

        <div class="row align-items-center block__69944">

          <div class="col-md-6">
            <img src="images/teams/team1.png" alt="Image" class="img-fluid mb-4 rounded">
          </div>

          <div class="col-md-6">
          <h3><strong>Jesryl Baguio</strong></h3>
          <p class=" text-dark"><strong>Full-Stack Developer</strong></p>
            <p>Responsible for building and maintaining the backbone of Jobsite Top's platform.</p>
            <p>Employing their expertise in both front-end and back-end development, Jesryl plays a pivotal role in designing and implementing the seamless user interface and robust functionality that Jobsite Top offers. From crafting intuitive user experiences to optimizing database performance, Jesryl's technical prowess ensures that Jobsite Top remains a user-friendly and reliable platform.</p>
            <div class="social mt-4">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-instagram"></span></a>
              <a href="#"><span class="icon-linkedin"></span></a>
            </div>
          </div>

          <div class="col-md-6 order-md-2 ml-md-auto">
            <img src="images/teams/person_5.jpg" alt="Image" class="img-fluid mb-4 rounded">
          </div>

          <div class="col-md-6">
          <h3><strong>Ian Castronuevo</strong></h3>
          <p class=" text-dark"><strong>Database Administrator</strong></p>
            <p>With a strong passion for managing and optimizing data systems, Ian plays a vital role in ensuring the reliability and efficiency of our platform.</p>
            <p>As a skilled Database Administrator, Ian is responsible for designing, implementing, and maintaining the databases that power Jobsite Top. With meticulous attention to detail and a deep understanding of database management systems, Ian ensures that our data is organized, secure, and easily accessible.</p>
            <div class="social mt-4">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-instagram"></span></a>
              <a href="#"><span class="icon-linkedin"></span></a>
            </div>
          </div>

      </div>
    </section>

    <?php require "includes/footer.php"; ?>