<?php require "../../config/config.php"; ?>
<?php
  session_start();
  define("ADMINURL", "https://jobsite.top/admin-panel");
?>

  <title>Admin Panel</title>
  <link href="<?php echo ADMINURL; ?>../../admin-panel/styles/login.css" rel="stylesheet">


<?php
    if(isset($_SESSION['adminname'])) {

    header("location:".ADMINURL."");
    }

    if(isset($_POST['submit'])) {

        if(empty($_POST['email']) OR empty($_POST['password'])) {
        echo "<script>alert('some inputs are empty')</script>";
        } else {

            //checked fot the form submission
            //we need to grap the data
            //do the query with the email only
            //we are going to execute and then fetch the data
            //check for the rowcount
            //check for the password

            $email = $_POST['email'];
            $password = $_POST['password'];

            $login = $conn->query("SELECT * FROM admins WHERE email = '$email'");
            $login->execute();

            $select = $login->fetch(PDO::FETCH_ASSOC);

            if($login->rowCount() > 0) {
                if(password_verify($password, $select['mypassword'])) {

                  $_SESSION['adminname'] = $select['adminname'];

                  $_SESSION['email'] = $select['email'];

                  header("location: ".ADMINURL."");

                  //echo "<script>alert('logged in')</script>";

                } else {
                    echo "<script>alert('invalid user')</script>";

                }
            } else {
                echo "<script>alert('invalid user')</script>";

            }

        }
    }

?>
      <div class="container">

          <div class="card" id="container-admin">
            <div class="text-center">
              <img class="logo" src="../../images/logo/android-chrome-384x384.png" alt="">
            </div>

            <div class="card-body">
              <h5 class="card-title">ADMIN PANEL</h5>
              <form method="POST" class="p-auto" action="login-admins.php">
                  <!-- Email input -->
                  <div class="form-outline ">
                    <input type="email" name="email" id="form2Example1" class="form-control" placeholder=" Email" required/>

                  </div>

                  <!-- Password input -->
                  <div class="form-outline ">
                    <input type="password" name="password" id="form2Example2" placeholder=" Password" class="form-control" required/>

                  </div>

                  <!-- Submit button -->
                  <button type="submit" name="submit" class="login-btn  text-center">Login</button>
                </form>
                <p class="forgot "><a href="../../404.php">Forgot your email or password?</a></p>
            </div>
       </div>
     </div>

</div>
<p class="terms">Terms & Services</p>
<p class="operated">Operated By:<a class="text-white" style="text-decoration: none; font-weight:bold; color:black ;" href="https://jobsite.top/"> WHITESPACE</a></p>
<?php require "../layouts/footer.php"; ?>
