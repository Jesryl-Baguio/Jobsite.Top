<!-- forgot_password.php -->
<?php require "../config/config.php"; ?>
<?php require "../includes/header.php"; ?>

<?php
if(isset($_SESSION['username'])){
    header("Location: ".APPURL."");
}

if (isset($_POST['submit'])) {
    $email = $_POST['email'];

    // Check if the email exists in the database
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {
        // Generate a unique token
        $resetToken = bin2hex(random_bytes(32));

        // Update the user's reset_token in the database
        $updateStmt = $conn->prepare("UPDATE users SET reset_token = ? WHERE id = ?");
        $updateStmt->execute([$resetToken, $user["id"]]);

        // Send email with reset link
        $resetLink = "http://jobsite.top/reset_password.php?token=$resetToken";
        $subject = "Password Reset";
        $message = "Click the following link to reset your password: $resetLink";
        mail($email, $subject, $message);

        echo "<script>alert('Password reset link sent to your email.');</script>";
    } else {
        echo "<script>alert('Email not found.');</script>";
    }
}
?>

<section class="section-hero overlay inner-page bg-image" style="background-image: url('<?php echo APPURL; ?>/images/hero_1.jpg');" id="home-section">
    <div class="container ">
        <div class="row ">
            <div class="col-md-7 ">
                <h1 class="text-white font-weight-bold">Forgot Password</h1>
                <div class="custom-breadcrumbs">
                    <a href="<?php echo APPURL; ?>">Home</a> <span class="mx-2 slash">/</span>
                    <span class="text-white"><strong>Forgot Password</strong></span>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="site-section">
    <div class="container w-25">
        <div class="row">
            <div class="col-md-12">
                <form action="forgot_password.php" method="POST" class="p-4 border rounded">
                    <div class="row form-group ">
                        <div class="col-md-12 mb-3 mb-md-0 ">
                            <label class="text-black" for="email">Email</label>
                            <input name="email" type="text" id="email" class="form-control" placeholder="Email address">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <input name="submit" type="submit" value="Reset Password" class="btn px-4 btn-primary text-white">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require "../includes/footer.php"; ?>