<?php require "../config/config.php" ?>
<?php require "../includes/header.php" ?>

<?php
if(isset($_SESSION['username'])){
  header("Location: ".APPURL."");
}
if (isset($_POST['submit'])) {

    $username = $_POST['username'];
    $password = $_POST['password'];
    $email = $_POST['email'];
    $fpassword = $_POST['fpassword'];
    $type = $_POST['type'];
    $img = 'defaultpic.jpg';

    if (empty($username) || empty($password) || empty($email) || empty($fpassword)) {
        echo "<script>alert('Some inputs are missing!');</script>";
    } else {
        // Check if email is already taken
        $emailCheck = $conn->prepare("SELECT * FROM users WHERE email = :email"); //prepare queries
        $emailCheck->execute([':email' => $email]); //execute email search in sql
        $existingEmailUser = $emailCheck->fetch(PDO::FETCH_ASSOC); //return found serach

         // Check if username is already taken
        $usernameCheck = $conn->prepare("SELECT * FROM users WHERE username = :username");
        $usernameCheck->execute([':username' => $username]);
        $existingUsernameUser = $usernameCheck->fetch(PDO::FETCH_ASSOC);

        if ($existingEmailUser) {
            echo "<script>alert('Email Already taken');</script>";
        } elseif ($existingUsernameUser) {
            echo "<script>alert('Username Already Taken');</script>";
        } else {
            if ($password == $fpassword) {
                $insert = $conn->prepare("INSERT INTO users (username, email, mypassword, img,type)
                  VALUES (:username, :email, :mypassword, :img, :type)");

                $insert->execute([
                    ':username' => $username,
                    ':email' => $email,
                    ':mypassword' => password_hash($password, PASSWORD_DEFAULT),
                    ':img' => $img,
                    ':type' => $type,
                ]);

                // echo "<script>alert('Welcome!'); setTimeout(function(){ window.location.href = 'login.php'; }, 1000);</script>";
                //render to login.php
                header('location: login.php');
            } else {
                echo "<script>alert('Password does not Match');</script>";;
            }
        }
    }
}

?>

    <!-- HOME -->
    <section class="section-hero overlay inner-page bg-image" style="background-image: url('../images/banner/gen-banner2.png');" id="home-section">
      <div class="container">
        <div class="row">
          <div class="col-md-7">
            <h1 class="text-white font-weight-bold">Register</h1>
            <div class="custom-breadcrumbs">
              <a href="<?php echo APPURL; ?>">Home</a> <span class="mx-2 slash">/</span>
              <span class="text-white"><strong>Register</strong></span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section ">
      <div class="container " id="container-reg">
        <div class="row">
          <div class="col-md-12 mb-5">
            <form action="register.php" class="p-4 border rounded" method="POST">

              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="text-black" for="fname" >Username</label>
                  <input type="text" id="fname" class="form-control" placeholder="Username" name="username">
                </div>
              </div>
              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="text-black" for="email">Email</label>
                  <input type="text" id="email" maxlength="50" class="form-control" placeholder="Email address" name="email">
                </div>
              </div>
              <div class="form-group">
                <label for="user-type">User Type</label>
                <select name="type" class="selectpicker border rounded" id="user-type" data-style="btn-black" data-width="100%" data-live-search="true" title="Select User Type">
                  <option>Employee</option>
                  <option>Company</option>
                </select>
              </div>
              <div class="row form-group">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="text-black" for="pasword">Password</label>
                  <input name="password" type="password" id="password" class="form-control" placeholder="Password">
                </div>
              </div>
              <div class="row form-group mb-4">
                <div class="col-md-12 mb-3 mb-md-0">
                  <label class="text-black" for="fpasword">Re-Type Password</label>
                  <input  type="password" id="fpassword" class="form-control" name="fpassword" placeholder="Re-type Password">
                </div>
              </div>

              <div class="row form-group">
                <div class="col-md-12">
                  <input name="submit" type="submit" value="Sign Up" class="btn px-4 btn-primary text-white">
                </div>
              </div>

            </form>
          </div>
        </div>
      </div>
    </section>

    <?php require "../includes/footer.php"; ?>