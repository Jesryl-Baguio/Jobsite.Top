<!-- reset_password.php -->
<?php require "../config/config.php"; ?>
<?php require "../includes/header.php"; ?>

<?php
// Check if the token is provided in the URL
//if(!isset($_GET['token'])) {
//   header("Location:".APPURL."");
//   exit();
//}

//$token = $_GET['token'];

// Check if the token exists in the database
//$stmt = $conn->prepare("SELECT id FROM users WHERE reset_token = ?");
//$stmt->execute([$token]);
//$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    echo "Invalid or expired token.";
    exit();
}

if (isset($_POST['submit'])) {
    $newPassword = $_POST['new_password'];

    // Hash the new password
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);

    // Update the user's password and reset_token in the database
    $updateStmt = $conn->prepare("UPDATE users SET mypassword = ?, reset_token = NULL WHERE id = ?");
    $updateStmt->execute([$hashedPassword, $user["id"]]);

    echo "Password reset successful. You can now <a href='login.php'>log in</a> with your new password.";
    exit();
}
?>

<section class="section-hero overlay inner-page bg-image" style="background-image: url('<?php echo APPURL; ?>/images/hero_1.jpg');" id="home-section">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <h1 class="text-white font-weight-bold">Reset Password</h1>
                <div class="custom-breadcrumbs">
                    <a href="<?php echo APPURL; ?>">Home</a> <span class="mx-2 slash">/</span>
                    <span class="text-white"><strong>Reset Password</strong></span>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="site-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <form action="reset_password.php?token=<?php echo $token; ?>" method="POST" class="p-4 border rounded">
                    <div class="row form-group">
                        <div class="col-md-12 mb-3 mb-md-0">
                            <label class="text-black" for="new_password">New Password</label>
                            <input type="password" name="new_password" id="new_password" class="form-control" placeholder="New Password">
                        </div>
                    </div>
                    <div class="row form-group">
                        <div class="col-md-12">
                            <input name="submit" type="submit" value="Reset Password" class="btn px-4 btn-primary text-white">
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>

<?php require "../includes/footer.php"; ?>
