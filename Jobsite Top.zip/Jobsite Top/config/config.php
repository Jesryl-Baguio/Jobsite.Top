<?php
try{
//$host = 'localhost';
//$dbname = 'jobhunter';
//$user = 'root';
//$pass = '';

//! Hosting Infinity free + godadday domain
$host = 'sql304.infinityfree.com';
$dbname = 'if0_35725693_jobhunter';
$user = 'if0_35725693';
$pass = 'Vash2005';


$conn = new PDO ("mysql:host=$host;dbname=$dbname", $user, $pass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION); //for additional error handling check php documentation

} catch (PDOException $e){
    echo "Error: " . $e->getMessage();
}

// if($conn = true){
//     echo "connected successfuly";
// }else{
//     echo "err";
// }

?>