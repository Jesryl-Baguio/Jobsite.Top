<footer class="site-footer">

      <a href="#top" class="smoothscroll scroll-top">
        <span class="icon-keyboard_arrow_up"></span>
      </a>

      <div class="container" id="footer-div">
        <div class="row mb-5">
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>SEARCHES</h3>
            <ul class="list-unstyled">
              <li><a href="#">Web Design</a></li>
              <li><a href="#">Graphic Design</a></li>
              <li><a href="#">Web Developers</a></li>
              <li><a href="#">Cloud Engineer</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>COMPANY</h3>
            <ul class="list-unstyled">
            <li><a href="#">Blog</a></li>
              <li><a href="#">Career</a></li>
              <li><a href="#">Resources</a></li>
              <li><a href="#">About Us</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>SUPPORT</h3>
            <ul class="list-unstyled">
              <li><a href="https://jobsite.top/admin-panel/admins/login-admins.php">Privacy</a></li>
              <li><a href="#">Message Us</a></li>
              <li><a href="#">Terms of Service</a></li>
              <li><a href="#">Customer Service</a></li>
            </ul>
          </div>
          <div class="col-6 col-md-3 mb-4 mb-md-0">
            <h3>CONTACT</h3>
            <div class="footer-social">
              <a href="#"><span class="icon-facebook"></span></a>
              <a href="#"><span class="icon-twitter"></span></a>
              <a href="#"><span class="icon-instagram"></span></a>
              <a href="#"><span class="icon-linkedin"></span></a>
            </div>
          </div>
        </div>

        <div class="row text-center">
          <div class="col-12">
            <p class="copyright">
            Copyright &copy; <script>document.write(new Date().getFullYear());</script> All rights reserved | Operated by<a class="text-white" href="https://jobsite.top/admin-panel/admins/login-admins.php" style="text-decoration: none;"> WHITESPACE</a>
          </div>
        </div>
      </div>
    </footer>
  </div>

    <!-- SCRIPTS -->
    <script src="https://jobsite.top/js/jquery.min.js"></script>
    <script src="https://jobsite.top/js/bootstrap.bundle.min.js"></script>
    <script src="https://jobsite.top/js/isotope.pkgd.min.js"></script>
    <script src="https://jobsite.top/js/stickyfill.min.js"></script>
    <script src="https://jobsite.top/js/jquery.fancybox.min.js"></script>
    <script src="https://jobsite.top/js/jquery.easing.1.3.js"></script>
    <script src="https://jobsite.top/js/jquery.waypoints.min.js"></script>
    <script src="https://jobsite.top/js/jquery.animateNumber.min.js"></script>
    <script src="https://jobsite.top/js/owl.carousel.min.js"></script>
    <script src="https://jobsite.top/js/quill.min.js"></script>
    <script src="https://jobsite.top/js/bootstrap-select.min.js"></script>
    <script src="https://jobsite.top/js/custom.js"></script>
  </body>
</html>