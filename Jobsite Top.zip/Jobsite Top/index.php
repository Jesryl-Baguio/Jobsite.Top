<?php require "includes/header.php";?>
<?php require "config/config.php";?>

<?php
  $select = $conn->query("SELECT * FROM jobs  WHERE status = 1 ORDER BY created_at DESC LIMIT 5");
  $select->execute();
  $jobs = $select->fetchAll(PDO::FETCH_OBJ);
  $searches = $conn->query("SELECT COUNT(keyword) AS count, keyword FROM searches
   GROUP BY keyword ORDER BY count DESC LIMIT 4");
  $searches->execute();
  $allSearches = $searches->fetchAll(PDO::FETCH_OBJ);
?>

<!-- COUNT LOGIC -->
<?php
  //Count all candidates
  $count_users = $conn->query("SELECT COUNT(*) AS candidates FROM users WHERE type = 'Employee' ");
  $count_users->execute();
  $count_candidates = $count_users->fetch(PDO::FETCH_OBJ);

  //Count ll companies
  $count_company = $conn->query("SELECT COUNT(*) AS companies FROM users WHERE type = 'Company' ");
  $count_company->execute();
  $count_companies = $count_company->fetch(PDO::FETCH_OBJ);

  //Count all jobs
  $jobs_total = $conn->query("SELECT COUNT(*) AS count_jobs FROM jobs");
  $jobs_total->execute();
  $counJobs = $jobs_total->fetch(PDO::FETCH_OBJ);

 //Count all job applied
 $job_apply = $conn->query("SELECT COUNT(*) AS application FROM job_applications");
 $job_apply->execute();
 $job_filled = $job_apply->fetch(PDO::FETCH_OBJ);
?>

    <!-- HOME -->
    <section class="home-section section-hero overlay bg-image" style="background-image: url('images/banner/header-banner-final.png');" id="home-section">
      <div class="container">
        <div class="row align-items-center justify-content-center">
          <div class="col-md-12">
            <div class="mb-5 text-center">
              <h1 class="text-white ">Get your disired jobs from the largest companies</h1>
              <p>Find jobs at any level of experience in a variety of industries at our 130k remote and local job listings.</p>
            </div>
            <form method="post" action="search.php" class="search-jobs-form">
              <div class="row mb-5">
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                  <input name="job-title" type="text" class="form-control form-control-lg" placeholder="Job title" required>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                  <select name="job-region" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Select Region" required>
                  <option>Philippines</option>
                  <option>United States</option>
                  <option>United Kingdom</option>
                  <option>Canada</option>
                  <option>Australia</option>
                  <option>Germany</option>
                  <option>France</option>
                  <option>Italy</option>
                  <option>Spain</option>
                  <option>Japan</option>
                  <option>China</option>
                  <option>India</option>
                  <option>Brazil</option>
                  <option>Mexico</option>
                  <option>South Korea</option>
                  <option>Russia</option>
                  <option>South Africa</option>
                  <option>Saudi Arabia</option>
                  <option>Argentina</option>
                  <option>Turkey</option>
                  <option>Netherlands</option>
                  <option>Switzerland</option>
                  <option>Sweden</option>
                  <option>Belgium</option>
                  <option>Norway</option>
                  <option>Austria</option>
                  <option>Denmark</option>
                  <option>Finland</option>
                  <option>Poland</option>
                  <option>Portugal</option>
                  <option>Greece</option>
                  <option>Ireland</option>
                  <option>Israel</option>
                  <option>Egypt</option>
                  <option>Thailand</option>
                  <option>Malaysia</option>
                  <option>Singapore</option>
                  <option>Indonesia</option>
                  <option>Philippines</option>
                  <option>Vietnam</option>
                  <option>New Zealand</option>
                  <option>Colombia</option>
                  <option>Chile</option>
                  <option>Peru</option>
                  <option>Iran</option>
                  <option>Iraq</option>
                  <option>Nigeria</option>
                  <option>Kenya</option>
                  <option>Morocco</option>
                  <option>Ethiopia</option>
                  </select>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                  <select name="job-type" class="selectpicker" data-style="btn-white btn-lg" data-width="100%" data-live-search="true" title="Select Job Type" required>
                    <option>Part Time</option>
                    <option>Full Time</option>
                  </select>
                </div>
                <div class="col-12 col-sm-6 col-md-6 col-lg-3 mb-4 mb-lg-0">
                  <button type="submit" name="submit" class="btn btn-primary btn-lg btn-block text-white btn-search"><span class="icon-search icon mr-2"></span>Search Job</button>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 popular-keywords">
                  <h3>Trending Search:</h3>
                  <ul class="keywords list-unstyled m-0 p-0">
                    <?php foreach($allSearches as $search):?>
                      <li><a href="#" class=""><?php echo $search->keyword;?></a></li>
                    <?php endforeach;?>
                  </ul>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <a href="#next" class="scroll-button smoothscroll">
        <span class=" icon-keyboard_arrow_down"></span>
      </a>
    </section>
    <section class="py-5 bg-image overlay-primary fixed overlay" id="next" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-12  text-center">
            <h2 class="section-title mb-2 text-white">WHY WE'RE THE BEST</h2>
            <p class="lead text-white" style="font-family: 'Poppins', sans-serif;">We been helping workers to find their dream jobs for more than 4 years, and it continues to grow.</p>
          </div>
        </div>
        <div class="row pb-0 block__19738 section-counter">
          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="<?php echo $count_candidates->candidates;?>">0</strong>
            </div>
            <span class="caption">Candidates</span>
          </div>

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number=" <?php echo $counJobs->count_jobs;?>">0</strong>
            </div>
            <span class="caption">Jobs Posted</span>
          </div>

          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="<?php echo $job_filled->application;?>">0</strong>
            </div>
            <span class="caption">Jobs Filled</span>
          </div>
          <div class="col-6 col-md-6 col-lg-3 mb-5 mb-lg-0">
            <div class="d-flex align-items-center justify-content-center mb-2">
              <strong class="number" data-number="<?php echo $count_companies->companies;?>">0</strong>
            </div>
            <span class="caption">Companies</span>
          </div>
        </div>
        <h2 class="section-title text-center text-white mt-5">There are 20+ job categories available</h2>
      </div>

    </section>
    <section class="site-section">
      <div class="container">
        <div class="row mb-5 justify-content-center">
          <div class="col-md-7 text-center">
            <h2 class="section-title mb-2 text-dark">5,161 Job Listed</h2>
          </div>
        </div>
        <ul class="job-listings mb-5">
          <?php foreach($jobs as $job):?>
            <li class="job-listing d-block d-sm-flex pb-3 pb-sm-0 align-items-center">
            <?php if(isset($_SESSION['username'])) : ?>
              <a href="jobs/job-single.php?id=<?php echo $job->id;?>"></a>
              <?php endif; ?>
              <div class="job-listing-logo">
                <img src="users/user-images/<?php echo $job->company_image;?>" alt="<?php echo $job->company_image;?>" class="img-fluid p-3">
              </div>
              <div class="job-listing-about d-sm-flex custom-width w-100 justify-content-between mx-4">
                <div class="job-listing-position custom-width w-50 mb-3 mb-sm-0">
                  <h2><?php echo $job->job_title;?></h2>
                  <strong><?php echo $job->company_name;?></strong>
                </div>
                <div class="job-listing-location mb-3 mb-sm-0 custom-width w-25">
                  <span class="icon-room"></span><?php echo $job->job_region;?>
                </div>
                <div class="job-listing-meta">
                <span class="badge badge-<?php if($job->job_type == 'Part Time') { echo 'danger'; } else{ echo 'success'; } ?>"><?php echo $job->job_type;?></span>
                </div>
              </div>
            </li>
            <br>
          <?php endforeach;?>

        </ul>
      </div>
    </section>
    <section class="py-5 bg-image overlay-primary fixed overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row align-items-center">
          <div class="col-md-8">
            <h2 class="text-white" style="font-family: 'Poppins', sans-serif;">Sign up now and find your dream job</h2>
            <p class="mb-0 text-white "style="font-family: 'Poppins', sans-serif;">We present an easy and fast way for job seekers to find suitable jobs for them, so let's register yourself and get started.</p>
          </div>
          <div class="col-md-3 ml-auto">
            <a href="<?php echo APPURL;?>auth/register.php" class="btn btn-dark btn-block btn-lg" style="font-family: 'Poppins', sans-serif;">Get Started</a>
          </div>
        </div>
      </div>
    </section>

    <section class="site-section py-4">
      <div class="container">

        <div class="row align-items-center">
          <div class="col-12 text-center mt-4 mb-5">
            <div class="row justify-content-center">
              <div class="col-md-7">
                <h2 class="section-title mb-2 text-dark">Some of our partner companies</h2>
              </div>
            </div>

          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_mailchimp.svg" alt="Image" class="img-fluid logo-1">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_paypal.svg" alt="Image" class="img-fluid logo-2">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_stripe.svg" alt="Image" class="img-fluid logo-3">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_visa.svg" alt="Image" class="img-fluid logo-4">
          </div>

          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_apple.svg" alt="Image" class="img-fluid logo-5">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_tinder.svg" alt="Image" class="img-fluid logo-6">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_sony.svg" alt="Image" class="img-fluid logo-7">
          </div>
          <div class="col-6 col-lg-3 col-md-6 text-center">
            <img src="images/logo_airbnb.svg" alt="Image" class="img-fluid logo-8">
          </div>
        </div>
      </div>
    </section>


    <section class="bg-light pt-5 testimony-full">
    <h4 class="text-center text-dark tesimony" style="font-weight: bold; font-family: 'Poppins', sans-serif;" >Candidates Testimonials</h4>
        <div class="owl-carousel single-carousel">
          <div class="container">
            <div class="row">
              <div class="col-lg-6 align-self-center text-center text-lg-left">
              <blockquote>
                  <p>&ldquo;Thanks to Jobsite.Top, I quickly landed my dream job. The user-friendly interface and seamless application process made it a breeze. Highly recommended!&rdquo;</p>
                  <p><cite> &mdash; Jhon Doe, Philippines</cite></p>
                </blockquote>
              </div>
              <div class="col-lg-6 align-self-end text-center text-lg-right">
                <img src="images/testimony/testimony-1.png" alt="Image" class="img-fluid mb-0">
              </div>
            </div>
          </div>

          <div class="container">
            <div class="row">
              <div class="col-lg-6 align-self-center text-center text-lg-left">
                <blockquote>
                  <p>&ldquo;Jobsite.Top exceeded my expectations. The quality job listings and user-friendly interface made it easy to navigate. I highly endorse it for a seamless job search.&rdquo;</p>
                  <p><cite> &mdash;Maria Rodriguez, Spain</cite></p>
                </blockquote>
              </div>
              <div class="col-lg-6 align-self-end text-center text-lg-right">
                <img src="images/testimony/testimony-2.png" alt="Image" class="img-fluid mb-0">
              </div>
            </div>
          </div>

          <div class="container">
            <div class="row">
              <div class="col-lg-6 align-self-center text-center text-lg-left">
                <blockquote>
                  <p>&ldquo;This job site made my entry-level job search a breeze. I secured a job aligned with my goals within a month. Great resources and filters.&rdquo;</p>
                  <p><cite> &mdash; Jean-Luc Dubois, France</cite></p>
                </blockquote>
              </div>
              <div class="col-lg-6 align-self-end text-center text-lg-right">
                <img src="images/testimony/testimony-3.png" alt="Image" class="img-fluid mb-0">
              </div>
            </div>
          </div>

          <div class="container">
            <div class="row">
              <div class="col-lg-6 align-self-center text-center text-lg-left">
                <blockquote>
                  <p>&ldquo;This job site stands out from the rest. Quality job listings, seamless application process. Found a perfect job quickly. Highly recommended.&rdquo;</p>
                  <p><cite> &mdash; Marco Rossi, Italy</cite></p>
                </blockquote>
              </div>
              <div class="col-lg-6 align-self-end text-center text-lg-right">
                <img src="images/testimony/testimony-4.png" alt="Image" class="img-fluid mb-0">
              </div>
            </div>
          </div>

      </div>

    </section>

    <section class="pt-5 bg-image overlay-primary fixed overlay" style="background-image: url('images/hero_1.jpg');">
      <div class="container">
        <div class="row">
          <div class="col-md-6 align-self-center text-center text-md-left mb-5 mb-md-0">
            <h2 class="text-white" style="font-family: 'Poppins', sans-serif; font-weight:bold;">Seamless Access, Anytime, Anywhere!</h2>
            <p class="mb-5 lead text-white">Explore Opportunities on the Go and seamlessly connect with employers.  Our platform is designed to be mobile-friendly and intuitive, ensuring a smooth and hassle-free job search experience. Pursue your career goals on your terms, knowing that your dream job is within reach, wherever you are.</p>
            <p class="mb-0">
              <!-- <a href="</?php echo APPURL;?>/404.php" class="btn btn-dark btn-md px-4 border-width-2"><span class="icon-apple mr-3"></span>App Store</a>
              <a href="</?php echo APPURL;?>/404.php" class="btn btn-dark btn-md px-4 border-width-2"><span class="icon-android mr-3"></span>Play Store</a> -->
            </p>
          </div>
          <div class="col-md-6 ml-auto align-self-end">
            <img src="images/banner/mockup.png" alt="" class="img-fluid">
          </div>
        </div>
      </div>
    </section>
<?php require "includes/footer.php";?>