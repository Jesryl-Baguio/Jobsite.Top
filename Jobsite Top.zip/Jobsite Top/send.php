<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
//require 'vendor/autoload.php';
require './PHPMailer/src/PHPMailer.php';
require './PHPMailer/src/SMTP.php';
require './PHPMailer/src/Exception.php';

// Start session
session_start();

// Process form using PHPMailer
if (isset($_POST['send'])) {
  $firstname = $_POST['firstname'];
  $lastname = $_POST['lastname'];
  $email = $_POST['email'];
  $subject = $_POST['subject'];
  $message = $_POST['message'];

$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'jobsite.top@gmail.com';
    $mail->Password   = 'jtavowvumxbouhcn';
    $mail->Port       = 587;

    //Recipients
    $mail->setFrom($email, $firstname);
    $mail->addAddress('jobsite.top@gmail.com', 'Jobsite Admin');

    //Sender
    $mail->isHTML(true);
    $mail->Subject = 'Message from: '.$firstname.' '.$lastname ;
    $mail->Body = "
        <h3>Application Details:</h3>
        <p><strong>First Name:</strong> $firstname</p>
        <p><strong>Last Name:</strong> $lastname</p>
        <p><strong>Subject:</strong> $subject</p>
        <p><strong>Email:</strong> $email</p>
        <p><strong>Message:</strong> $message</p>
        ";

    $mail->send();


    $_SESSION['message'] = 'Sent Successfully';
    //header('location:'.'https://jobsite.top/contact.php');
} catch (Exception $e) {
    $_SESSION['message'] = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    //$message = "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";

}
    // Redirect to contact.php
    header('Location: contact.php');
    exit();

}
?>